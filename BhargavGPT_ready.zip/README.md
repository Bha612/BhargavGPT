# BhargavGPT - Ready to Run (Flask)

## What this is
A minimal Flask chat app named BhargavGPT that connects to the OpenAI API.

## Quick start (local)
1. Unzip the project.
2. Create a virtual environment and install dependencies:

   ```bash
   python -m venv venv
   venv\Scripts\activate    # Windows
   # OR
   # source venv/bin/activate  # macOS / Linux
   pip install -r requirements.txt
   ```

3. Create a `.env` file (or set environment variable) containing your API key:

   ```text
   OPENAI_API_KEY=sk-...your key...
   ```

4. Run the app:

   ```bash
   python app.py
   ```

5. Open http://127.0.0.1:5000 in your browser.

## Deployable
This project includes a `Procfile` for simple deployment platforms (Heroku/Render).
Set the `OPENAI_API_KEY` environment variable on the host before starting the app.

## Notes
- Conversation state is not persisted across server restarts.
- Monitor your OpenAI usage to avoid unexpected charges.
